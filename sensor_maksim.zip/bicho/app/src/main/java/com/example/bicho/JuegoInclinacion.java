package com.example.bicho;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class JuegoInclinacion extends View implements SensorEventListener {

    private static class Pulgon {
        float x, y, angulo;
        Pulgon(float x, float y, float angulo) {
            this.x = x;
            this.y = y;
            this.angulo = angulo;
        }
    }

    private static class Hormiga {
        float x, y, angulo;
        float velocidad = 3.5f;
        Hormiga(float x, float y) {
            this.x = x;
            this.y = y;
        }

        void perseguir(float targetX, float targetY, List<Hormiga> todas, float radioH) {
            float dx = targetX - x;
            float dy = targetY - y;
            float distancia = (float) Math.sqrt(dx * dx + dy * dy);
            
            float vx = 0;
            float vy = 0;

            if (distancia > 0) {
                vx = (dx / distancia) * velocidad;
                vy = (dy / distancia) * velocidad;
            }

            // Evitar colapsar con otras hormigas (Separación)
            for (Hormiga otra : todas) {
                if (otra == this) continue;
                float distX = x - otra.x;
                float distY = y - otra.y;
                float d = (float) Math.sqrt(distX * distX + distY * distY);
                
                if (d < radioH * 2.2f && d > 0) {
                    // Aplicar una fuerza de repulsión si están muy cerca
                    vx += (distX / d) * velocidad;
                    vy += (distY / d) * velocidad;
                }
            }

            x += vx;
            y += vy;
            
            // Actualizar ángulo basado en la dirección del movimiento real
            if (Math.abs(vx) > 0.1 || Math.abs(vy) > 0.1) {
                angulo = (float) Math.toDegrees(Math.atan2(vy, vx));
            }
        }
    }

    private Paint pincelTexto;
    private Paint pincelVidas;
    private Bitmap bichoBitmap;
    private Bitmap pulgonBitmap;
    private Bitmap hormigaBitmap;
    private Bitmap fondoBitmap;
    
    private float posX, posY;
    private float radioBicho = 60f;
    private float radioItem = 40f;
    private float radioHormiga = 45f;
    private float anguloBicho = 0f;
    
    private SensorManager sensorManager;
    private Sensor acelerometro;
    
    private List<Pulgon> items;
    private List<Hormiga> hormigas;
    private int puntuacion = 0;
    private int vidas = 5;
    private Random random;

    public JuegoInclinacion(Context context) {
        super(context);

        fondoBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.fondo);

        Bitmap originalBicho = BitmapFactory.decodeResource(getResources(), R.drawable.ladybug);
        bichoBitmap = Bitmap.createScaledBitmap(originalBicho, (int)radioBicho * 2, (int)radioBicho * 2, true);

        Bitmap originalPulgon = BitmapFactory.decodeResource(getResources(), R.drawable.pulgon);
        pulgonBitmap = Bitmap.createScaledBitmap(originalPulgon, (int)radioItem * 2, (int)radioItem * 2, true);

        Bitmap originalHormiga = BitmapFactory.decodeResource(getResources(), R.drawable.hormiga);
        hormigaBitmap = Bitmap.createScaledBitmap(originalHormiga, (int)radioHormiga * 2, (int)radioHormiga * 2, true);

        pincelTexto = new Paint();
        pincelTexto.setColor(Color.WHITE);
        pincelTexto.setTextSize(60f);
        pincelTexto.setFakeBoldText(true);
        pincelTexto.setShadowLayer(5, 2, 2, Color.BLACK);

        pincelVidas = new Paint();
        pincelVidas.setColor(Color.RED);
        pincelVidas.setShadowLayer(5, 2, 2, Color.BLACK);

        items = new ArrayList<>();
        hormigas = new ArrayList<>();
        random = new Random();

        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        acelerometro = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(this, acelerometro, SensorManager.SENSOR_DELAY_GAME);
    }

    private void reiniciarJuego() {
        vidas = 5;
        puntuacion = 0;
        items.clear();
        hormigas.clear();
        posX = getWidth() / 2f;
        posY = getHeight() / 2f;
        generarItems(5);
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (vidas <= 0 && event.getAction() == MotionEvent.ACTION_DOWN) {
            reiniciarJuego();
            return true;
        }
        return super.onTouchEvent(event);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int ancho = getWidth();
        int alto = getHeight();

        if (fondoBitmap != null) {
            canvas.save();
            canvas.translate(ancho / 2f, alto / 2f);
            canvas.rotate(90);
            Rect dest = new Rect(-alto / 2, -ancho / 2, alto / 2, ancho / 2);
            canvas.drawBitmap(fondoBitmap, null, dest, null);
            canvas.restore();
        }

        if (posX == 0) {
            posX = ancho / 2f;
            posY = alto / 2f;
            generarItems(5);
        }

        if (vidas <= 0) {
            pincelTexto.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("GAME OVER", ancho/2f, alto/2f, pincelTexto);
            canvas.drawText("Puntos: " + puntuacion, ancho/2f, alto/2f + 80, pincelTexto);
            canvas.drawText("Toca para reiniciar", ancho/2f, alto/2f + 160, pincelTexto);
            return;
        }

        // Manejar hormigas
        if (hormigas.size() < 2 && random.nextInt(100) < 2) {
            generarHormiga();
        }

        for (Hormiga h : hormigas) {
            h.perseguir(posX, posY, hormigas, radioHormiga);
            canvas.save();
            canvas.rotate(h.angulo, h.x, h.y);
            canvas.drawBitmap(hormigaBitmap, h.x - radioHormiga, h.y - radioHormiga, null);
            canvas.restore();
        }

        for (Pulgon p : items) {
            canvas.save();
            canvas.rotate(p.angulo, p.x, p.y);
            canvas.drawBitmap(pulgonBitmap, p.x - radioItem, p.y - radioItem, null);
            canvas.restore();
        }

        canvas.save();
        canvas.rotate(anguloBicho, posX, posY);
        canvas.drawBitmap(bichoBitmap, posX - radioBicho, posY - radioBicho, null);
        canvas.restore();

        // Dibujar UI
        pincelTexto.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("Puntos: " + puntuacion, ancho - 50, 100, pincelTexto);
        
        // Dibujar corazones/puntos de vida
        for (int i = 0; i < vidas; i++) {
            canvas.drawCircle(60 + (i * 60), 80, 20, pincelVidas);
        }

        comprobarColisiones();

        if (items.size() < 3) {
            generarItems(1);
        }

        invalidate();
    }

    private void generarItems(int cantidad) {
        for (int i = 0; i < cantidad; i++) {
            float x = radioItem + random.nextFloat() * (getWidth() - 2 * radioItem);
            float y = radioItem + random.nextFloat() * (getHeight() - 2 * radioItem);
            float anguloAleatorio = random.nextFloat() * 360f;
            items.add(new Pulgon(x, y, anguloAleatorio));
        }
    }

    private void generarHormiga() {
        float x, y;
        // Aparecen por los bordes
        if (random.nextBoolean()) {
            x = random.nextBoolean() ? -radioHormiga : getWidth() + radioHormiga;
            y = random.nextFloat() * getHeight();
        } else {
            x = random.nextFloat() * getWidth();
            y = random.nextBoolean() ? -radioHormiga : getHeight() + radioHormiga;
        }
        hormigas.add(new Hormiga(x, y));
    }

    private void comprobarColisiones() {
        // Colisión con pulgones
        List<Pulgon> itemsAEliminar = new ArrayList<>();
        for (Pulgon p : items) {
            double distancia = Math.sqrt(Math.pow(posX - p.x, 2) + Math.pow(posY - p.y, 2));
            if (distancia < (radioBicho * 0.8 + radioItem * 0.8)) {
                itemsAEliminar.add(p);
                puntuacion++;
            }
        }
        items.removeAll(itemsAEliminar);

        // Colisión con hormigas
        List<Hormiga> hormigasAEliminar = new ArrayList<>();
        for (Hormiga h : hormigas) {
            double distancia = Math.sqrt(Math.pow(posX - h.x, 2) + Math.pow(posY - h.y, 2));
            if (distancia < (radioBicho * 0.7 + radioHormiga * 0.7)) {
                hormigasAEliminar.add(h);
                vidas--;
            }
        }
        hormigas.removeAll(hormigasAEliminar);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (vidas <= 0) return;

        float movY = event.values[0];
        float movX = event.values[1];

        float dx = movX * 7;
        float dy = movY * 7;

        if (Math.abs(dx) > 0.1 || Math.abs(dy) > 0.1) {
            anguloBicho = (float) Math.toDegrees(Math.atan2(dy, dx));
        }

        posX += dx;
        posY += dy;

        if (posX < radioBicho) posX = radioBicho;
        if (posX > getWidth() - radioBicho) posX = getWidth() - radioBicho;
        if (posY < radioBicho) posY = radioBicho;
        if (posY > getHeight() - radioBicho) posY = getHeight() - radioBicho;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}
}