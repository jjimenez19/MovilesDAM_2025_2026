package com.example.screeanm;

public class Shhhark extends Boss {

    public Shhhark() {
        super("Shhhark", 100);
    }

    @Override
    public void update() {

    }
}